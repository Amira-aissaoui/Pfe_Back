package com.expo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExpoApplicationTests {

	@Test
	void contextLoads() {
	}

}
