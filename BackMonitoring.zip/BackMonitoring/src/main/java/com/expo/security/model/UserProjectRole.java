package com.expo.security.model;

public enum UserProjectRole {
    EDITOR,
    VIEWER;
}
