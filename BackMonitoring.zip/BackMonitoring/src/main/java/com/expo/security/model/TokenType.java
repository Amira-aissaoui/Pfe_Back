package com.expo.security.model;

public enum TokenType {
  BEARER
}
