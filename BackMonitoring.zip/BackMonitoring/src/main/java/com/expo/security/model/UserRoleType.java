package com.expo.security.model;

public enum UserRoleType {

    EDITOR,
    VIEWER
}

