package com.expo.teams.model;

public enum TeamRole {
    VIEWER,
    EDITOR
}
