package com.expo.teams.service;

public class ConvertToTeamDTO {
}
