package com.expo.grafana.model;

import com.expo.grafana.service.ApiKeyUpdater;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;

public class DashboardManager {
    private String apiKey;
    @Value("${grafana.url}")

    private String grafanaUrl;
    
    private  final ApiKeyUpdater apikeyUpdate;


    public DashboardManager(String apiKey, String grafanaUrl, ApiKeyUpdater apikeyUpdate) {
        this.apiKey = apiKey;
        this.grafanaUrl = grafanaUrl;
        this.apikeyUpdate = apikeyUpdate;

    }
    @PostConstruct
    public void initialize() {
        this.apiKey = apikeyUpdate.getAPIKey();
    }




}
